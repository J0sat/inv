<?php
/**
 * Created by PhpStorm.
 * User: Popstarfreas
 * Date: 17/02/2015
 * Time: 18:35
 */

$config = array(
    'display_position' => true,
    'display_group' => false,
    'display_ip' => false
);